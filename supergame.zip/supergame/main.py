import pygame
import sys
import os
import sqlite3
from random import randint

con = sqlite3.connect("stats")
result = con.cursor().execute("""SELECT * FROM scoring""").fetchall()

pygame.init()
size = width, height = 800, 600
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption('Побег из подземельных переходов Симбирсковья')
running = True
jump = ''
all_sprites = pygame.sprite.Group()
jump_sprite = pygame.sprite.Group()
crates = ('images/crate.png', 'images/crate2.png')
STOPPED_PLAYING = pygame.USEREVENT + 1
pygame.mixer.music.set_endevent(STOPPED_PLAYING)
pygame.time.set_timer(pygame.USEREVENT, 3000)


def load_image(name, colorkey=None):
    fullname = name
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    return image


icon = load_image('images/icon.png')
pygame.display.set_icon(icon)
crat = []
for i in range(len(crates)):
    crat.append(pygame.image.load(crates[i]).convert_alpha())


def draw(screen):
    font = pygame.font.Font('TDIzbushka.otf', 36)
    text = font.render("Побег из подземельных переходов Симбирсковья", True, (10, 156, 247))
    text_x = width // 2 - text.get_width() // 2
    text_y = int(height * 0.2)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                           text_w + 20, text_h + 20), 3)
    recta = text_x - 10, text_y - 10, text_x - 10 + text_w + 20, text_y - 10 + text_h + 20

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render("Начать игру", True, (10, 156, 247))
    text_x = width // 2 - text.get_width() // 2
    text_y = int(height * 0.35)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                              text_w + 20, text_h + 20), 3)
    recta2 = text_x - 10, text_y - 10, text_x - 10 + text_w + 20, text_y - 10 + text_h + 20

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render("Недавняя статистика", True, (10, 156, 247))
    text_x = width // 2 - text.get_width() // 2
    text_y = int(height * 0.45)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                              text_w + 20, text_h + 20), 3)
    recta3 = text_x - 10, text_y - 10, text_x - 10 + text_w + 20, text_y - 10 + text_h + 20
    return recta, recta2, recta3


def draw2(screen, veloct=0):
    font = pygame.font.Font('TDIzbushka.otf', 20)
    text = font.render(f"Метров пройдено: {veloct}", True, (138, 0, 0))
    text_x = int(width * 0.05)
    text_y = int(height * 0.1)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (255, 54, 54), (text_x - 10, text_y - 10,
                                           text_w + 20, text_h + 20), 3)
    recta = text_x - 10, text_y - 10, text_x - 10 + text_w + 20, text_y - 10 + text_h + 20
    return recta


def draw3(screen, ehid, nickname=''):
    font = pygame.font.Font('TDIzbushka.otf', 36)
    text = font.render("Игра окончена", True, (10, 156, 247))
    text_x = width // 2 - text.get_width() // 2
    text_y = int(height * 0.1)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                              text_w + 20, text_h + 20), 3)
    recta01 = text_x - 10, text_y - 10, text_x - 10 + text_w, text_y - 10 + text_h + 20

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render("Результат:", True, (10, 156, 247))
    text_x = width // 2 - text.get_width() // 2
    text_y = int(height * 0.25)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                              text_w + 20, text_h + 20), 3)
    recta02 = text_x - 10, text_y - 10, text_x - 10 + text_w + 20, text_y - 10 + text_h + 20

    font = pygame.font.Font('TDIzbushka.otf', 36)
    text = font.render(f"{ehid} метров", True, (10, 156, 247))
    text_x = width // 2 - text.get_width() // 2
    text_y = int(height * 0.4)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                              text_w + 20, text_h + 20), 3)
    recta03 = text_x - 10, text_y - 10, text_x - 10 + text_w + 20, text_y - 10 + text_h + 20

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render("Введите имя русскими буквами английской раскладкой:", True, (10, 156, 247))
    text_x = width // 2 - text.get_width() // 2
    text_y = int(height * 0.55)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                              text_w + 20, text_h + 20), 3)
    recta04 = text_x - 10, text_y - 10, text_x - 10 + text_w + 20, text_y - 10 + text_h + 20

    font = pygame.font.Font('TDIzbushka.otf', 36)
    text = font.render(f"На главное меню", True, (10, 156, 247))
    text_x = int(width * 0.04)
    text_y = int(height * 0.85)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                              text_w + 20, text_h + 20), 3)
    recta05 = text_x - 10, text_y - 10, text_x - 10 + text_w + 20, text_y - 10 + text_h + 20

    font = pygame.font.Font('TDIzbushka.otf', 36)
    text = font.render(f"{nickname}", True, (10, 156, 247))
    text_x = width // 2 - text.get_width() // 2
    text_y = int(height * 0.65)
    screen.blit(text, (text_x, text_y))
    text_w = text.get_width()
    text_h = text.get_height()
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                              text_w + 20, text_h + 20), 3)

    return recta01, recta02, recta03, recta04, recta05


def showy(screen, result):
    font = pygame.font.Font('TDIzbushka.otf', 36)
    text = font.render("Недавняя статистика", True, (10, 156, 247))
    text_x = width // 2 - text.get_width() // 2
    text_y = int(height * 0.15)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                           text_w + 20, text_h + 20), 3)
    recti = text_x - 10, text_y - 10, text_x - 10 + text_w + 20, text_y - 10 + text_h + 20

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-1][0]}", True, (10, 156, 247))
    text_x = int(width * 0.25)
    text_y = int(height * 0.3)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-1][1]} метров", True, (10, 156, 247))
    text_x = int(width * 0.6)
    text_y = int(height * 0.3)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-2][0]}", True, (10, 156, 247))
    text_x = int(width * 0.25)
    text_y = int(height * 0.35)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-2][1]} метров", True, (10, 156, 247))
    text_x = int(width * 0.6)
    text_y = int(height * 0.35)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-3][0]}", True, (10, 156, 247))
    text_x = int(width * 0.25)
    text_y = int(height * 0.4)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-3][1]} метров", True, (10, 156, 247))
    text_x = int(width * 0.6)
    text_y = int(height * 0.4)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-4][0]}", True, (10, 156, 247))
    text_x = int(width * 0.25)
    text_y = int(height * 0.45)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-4][1]} метров", True, (10, 156, 247))
    text_x = int(width * 0.6)
    text_y = int(height * 0.45)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-5][0]}", True, (10, 156, 247))
    text_x = int(width * 0.25)
    text_y = int(height * 0.5)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-5][1]} метров", True, (10, 156, 247))
    text_x = int(width * 0.6)
    text_y = int(height * 0.5)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-6][0]}", True, (10, 156, 247))
    text_x = int(width * 0.25)
    text_y = int(height * 0.55)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-6][1]} метров", True, (10, 156, 247))
    text_x = int(width * 0.6)
    text_y = int(height * 0.55)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-7][0]}", True, (10, 156, 247))
    text_x = int(width * 0.25)
    text_y = int(height * 0.6)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-7][1]} метров", True, (10, 156, 247))
    text_x = int(width * 0.6)
    text_y = int(height * 0.6)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-8][0]}", True, (10, 156, 247))
    text_x = int(width * 0.25)
    text_y = int(height * 0.65)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-8][1]} метров", True, (10, 156, 247))
    text_x = int(width * 0.6)
    text_y = int(height * 0.65)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-9][0]}", True, (10, 156, 247))
    text_x = int(width * 0.25)
    text_y = int(height * 0.7)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-9][1]} метров", True, (10, 156, 247))
    text_x = int(width * 0.6)
    text_y = int(height * 0.7)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-10][0]}", True, (10, 156, 247))
    text_x = int(width * 0.25)
    text_y = int(height * 0.75)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 24)
    text = font.render(f"{result[-10][1]} метров", True, (10, 156, 247))
    text_x = int(width * 0.6)
    text_y = int(height * 0.75)
    screen.blit(text, (text_x, text_y))

    font = pygame.font.Font('TDIzbushka.otf', 36)
    text = font.render(f"На главное меню", True, (10, 156, 247))
    text_x = int(width * 0.04)
    text_y = int(height * 0.85)
    text_w = text.get_width()
    text_h = text.get_height()
    screen.blit(text, (text_x, text_y))
    pygame.draw.rect(screen, (10, 126, 227), (text_x - 10, text_y - 10,
                                              text_w + 20, text_h + 20), 3)
    recti04 = text_x - 10, text_y - 10, text_x - 10 + text_w + 20, text_y - 10 + text_h + 20
    return recti, recti04


class AnimatedSprite(pygame.sprite.Sprite):
    def __init__(self, sheet, columns, rows, x, y, group):
        super().__init__(group)
        self.frames = []
        self.cut_sheet(sheet, columns, rows)
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        self.rect = self.rect.move(x, y)

    def cut_sheet(self, sheet, columns, rows):
        self.rect = pygame.Rect(0, 0, sheet.get_width() // columns,
                                sheet.get_height() // rows)
        for j in range(rows):
            for i in range(columns):
                frame_location = (self.rect.w * i, self.rect.h * j)
                self.frames.append(sheet.subsurface(pygame.Rect(
                    frame_location, self.rect.size)))

    def update(self):
        self.cur_frame = (self.cur_frame + 1) % len(self.frames)
        self.image = self.frames[self.cur_frame]


class Crate(pygame.sprite.Sprite):
    def __init__(self, inag, x, y, v, group):
        super().__init__(group)
        pygame.sprite.Sprite.__init__(self)
        self.image = inag
        self.rect = self.image.get_rect()
        self.rect = self.rect.move(x, y)
        self.speed = v

    def update(self):
        if self.rect.x > -60:
            self.rect.x -= self.speed
        elif self.rect.x <= -60:
            self.kill()

    def getting_rect(self):
        return self.image.get_rect()


welsound = pygame.mixer.Sound('music/welmusic.mp3')
gamesound = pygame.mixer.Sound('music/musgame.mp3')
bgame = pygame.mixer.Sound('music/badgame.mp3')
ggame = pygame.mixer.Sound('music/goodgame.mp3')

v = 16
ehind = 0
bg_x = 0
welm = 0
game = False
loses = False
n = 16
jumping = False

img = pygame.image.load('images/title.png').convert_alpha()
img = pygame.transform.scale(img, (800, 600))
bgam = pygame.image.load('images/bgame.png').convert_alpha()
run = AnimatedSprite(load_image("images/flippin.png"), 3, 1, 80, 405, all_sprites)
crats = pygame.sprite.Group()
vocs = draw(screen)
vocs3 = draw3(screen, ehind)
tilider = showy(screen, con.cursor().execute("""SELECT * FROM scoring""").fetchall())

re = pygame.Surface((vocs[0][2] - vocs[0][0], vocs[0][3] - vocs[0][1]))
re.fill(pygame.Color((5, 5, 50)))
re2 = pygame.Surface((vocs[1][2] - vocs[1][0], vocs[1][3] - vocs[1][1]))
re2.fill(pygame.Color((5, 5, 50)))
re3 = pygame.Surface((vocs[2][2] - vocs[2][0], vocs[2][3] - vocs[2][1]))
re3.fill(pygame.Color((5, 5, 50)))
re4 = pygame.Surface((vocs[0][2] - vocs[2][0], vocs[2][3] - vocs[2][1]))
re01 = pygame.Surface((vocs3[0][2] - vocs3[0][0], vocs3[0][3] - vocs3[0][1]))
re01.fill(pygame.Color((5, 5, 50)))
re02 = pygame.Surface((vocs3[1][2] - vocs3[1][0], vocs3[1][3] - vocs3[1][1]))
re02.fill(pygame.Color((5, 5, 50)))
re03 = pygame.Surface((vocs3[2][2] - vocs3[2][0], vocs3[2][3] - vocs3[2][1]))
re03.fill(pygame.Color((5, 5, 50)))
re04 = pygame.Surface((vocs3[3][2] - vocs3[3][0], vocs3[3][3] - vocs3[3][1]))
re04.fill(pygame.Color((5, 5, 50)))
re05 = pygame.Surface((vocs3[4][2] - vocs3[4][0], vocs3[4][3] - vocs3[4][1]))
re05.fill(pygame.Color((5, 5, 50)))
ti = pygame.Surface((tilider[0][2] - tilider[0][0], tilider[0][3] - tilider[0][1]))
ti.fill(pygame.Color((5, 5, 50)))
ti2 = pygame.Surface((tilider[1][2] - tilider[1][0], tilider[1][3] - tilider[1][1]))
ti2.fill(pygame.Color((5, 5, 50)))
stas = pygame.Surface((450, 320))
stas.fill(pygame.Color((5, 5, 50)))

clock = pygame.time.Clock()
cr = 0
crit = ''
crit_rect = (0, 0, 0, 0)
jump_y = 385
welcome = True
leaders = False

while running:
    if welcome:
        if not welm:
            welm = 1
            welsound.play()
        else:
            nickname = ''
            screen.fill((5, 5, 50))
            screen.blit(img, (0, 0))
            screen.blit(re, (vocs[0][0], vocs[0][1]))
            screen.blit(re2, (vocs[1][0], vocs[1][1]))
            screen.blit(re3, (vocs[2][0], vocs[2][1]))
            draw(screen)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.pos[0] in range(vocs[1][0], vocs[1][2]) and event.pos[1] in range(vocs[1][1], vocs[1][3]):
                        welcome = False
                        game = True
                    elif event.pos[0] in range(vocs[2][0], vocs[2][2]) and event.pos[1] in range(vocs[2][1], vocs[2][3]):
                        welcome = False
                        leaders = True
                pygame.display.flip()
    elif leaders:
        screen.fill((5, 5, 50))
        screen.blit(img, (0, 0))
        screen.blit(ti, (tilider[0][0], tilider[0][1]))
        screen.blit(ti2, (tilider[1][0], tilider[1][1]))
        screen.blit(stas, (180, 170))
        pygame.draw.rect(screen, (10, 126, 227), (180, 170, 450, 320), 3)
        showy(screen, result)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.pos[0] in range(tilider[1][0], tilider[1][2]) and event.pos[1] in range(tilider[1][1], tilider[1][3]):
                    leaders = False
                    welcome = True
    elif game:
        if welm:
            welm = 0
            welsound.stop()
            gamesound.play()
        if run:
            screen.fill((5, 5, 50))
            screen.blit(bgam, (bg_x, 0))
            screen.blit(bgam, (bg_x + 800, 0))
        if cr:
            crit_rect = crit.getting_rect()
        draw2(screen, ehind)
        bg_x -= v
        ehind += 1
        if bg_x <= -800:
            bg_x = 0
        crats.update()
        crats.draw(screen)
        for i in crats.sprites():
            if pygame.sprite.spritecollideany(run, crats) and n not in range(-10, 10):
                game = False
                loses = True
                gamesound.stop()
        if not jumping:
            run.update()
            all_sprites.draw(screen)
            clock.tick(v)
        elif jumping:
            if n > 0:
                jump.kill()
                jump_y -= 5
                jump = AnimatedSprite(load_image("images/try2.png"),
                                      1, 1, 80, jump_y, jump_sprite)
                jump_sprite.draw(screen)
                clock.tick(v)
                n -= 1
            elif n == -17:
                jump.kill()
                run = AnimatedSprite(load_image("images/flippin.png"), 3, 1, 80, 405, all_sprites)
                all_sprites.draw(screen)
                jumping = False
                n = 16
            elif n < 0:
                jump_y += 5
                jump.kill()
                jump = AnimatedSprite(load_image("images/try2.png"),
                                      1, 1, 80, jump_y, jump_sprite)
                jump.update()
                jump_sprite.draw(screen)
                clock.tick(v)
                n -= 1
            else:
                jump.update()
                jump_sprite.draw(screen)
                n -= 1
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gamesound.stop()
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if n == 16:
                        run.kill()
                        jumping = True
                        jump = AnimatedSprite(load_image("images/try2.png"),
                                              1, 1, 80, jump_y, jump_sprite)
            if event.type == pygame.USEREVENT:
                crit = Crate(crat[randint(0, 1)], 800, 440, v, crats)
                crit_rect = crit.getting_rect()
                cr = 1
            if STOPPED_PLAYING == event.type:
                pass
                gamesound.play()
            pygame.display.flip()
    elif loses:
        if ehind < 1000:
            bgame.play()
        elif ehind >= 1000:
            ggame.play()
        screen.fill((5, 5, 50))
        screen.blit(img, (0, 0))
        screen.blit(re01, (vocs3[0][0], vocs3[0][1]))
        screen.blit(re02, (vocs3[1][0], vocs3[1][1]))
        screen.blit(re03, (vocs3[2][0], vocs3[2][1]))
        screen.blit(re04, (vocs3[3][0], vocs3[3][1]))
        screen.blit(re05, (vocs3[4][0], vocs3[4][1]))
        draw3(screen, ehind, nickname)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    nickname += 'й'
                elif event.key == pygame.K_w:
                    nickname += 'ц'
                elif event.key == pygame.K_e:
                    nickname += 'у'
                elif event.key == pygame.K_BACKQUOTE:
                    nickname += 'ё'

                if event.key == pygame.K_r:
                    nickname += 'к'
                elif event.key == pygame.K_t:
                    nickname += 'е'
                elif event.key == pygame.K_y:
                    nickname += 'н'
                elif event.key == pygame.K_u:
                    nickname += 'г'

                elif event.key == pygame.K_i:
                    nickname += 'ш'
                elif event.key == pygame.K_o:
                    nickname += 'щ'
                elif event.key == pygame.K_p:
                    nickname += 'з'
                elif event.key == pygame.K_LEFTBRACKET:
                    nickname += 'х'

                elif event.key == pygame.K_RIGHTBRACKET:
                    nickname += 'ъ'
                elif event.key == pygame.K_a:
                    nickname += 'ф'
                elif event.key == pygame.K_s:
                    nickname += 'ы'
                elif event.key == pygame.K_d:
                    nickname += 'в'

                if event.key == pygame.K_f:
                    nickname += 'а'
                elif event.key == pygame.K_g:
                    nickname += 'п'
                elif event.key == pygame.K_h:
                    nickname += 'р'
                elif event.key == pygame.K_j:
                    nickname += 'о'

                if event.key == pygame.K_k:
                    nickname += 'л'
                elif event.key == pygame.K_l:
                    nickname += 'д'
                elif event.key == pygame.K_SEMICOLON:
                    nickname += 'ж'
                elif event.key == pygame.K_QUOTE:
                    nickname += 'э'

                if event.key == pygame.K_z:
                    nickname += 'я'
                elif event.key == pygame.K_x:
                    nickname += 'ч'
                elif event.key == pygame.K_c:
                    nickname += 'с'
                elif event.key == pygame.K_v:
                    nickname += 'м'

                if event.key == pygame.K_b:
                    nickname += 'и'
                elif event.key == pygame.K_n:
                    nickname += 'т'
                elif event.key == pygame.K_m:
                    nickname += 'ь'
                elif event.key == pygame.K_COMMA:
                    nickname += 'б'
                elif event.key == pygame.K_PERIOD:
                    nickname += 'ю'
                elif event.key == pygame.K_RETURN:
                    con.cursor().execute(f'''INSERT INTO scoring(name,score) VALUES('{nickname}',{ehind})''')
                    con.commit()
                    result = con.cursor().execute("""SELECT * FROM scoring""").fetchall()
                    welcome = True
                    bgame.stop()
                    crats.clear(screen, img)
                    ehind = 0
                    cr = 0
                    run.kill()
                    n = 16
                    bg_x = 0
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.pos[0] in range(vocs3[4][0], vocs3[4][2]) and event.pos[1] in range(vocs3[4][1], vocs3[4][3]):
                    welcome = True
                    bgame.stop()
                    crats.clear(screen, img)
                    ehind = 0
                    cr = 0
                    run.kill()
                    n = 16
                    bg_x = 0
    pygame.display.flip()
pygame.quit()